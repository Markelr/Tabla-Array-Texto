public class Ejercicio10 {	
	public static void main(String[] args) {
		String[] cadenas = {"Sue", "Charlotte", "Anna", "Mike", "William", "Ed"};
	    boolean hayRepetidos=false;
	    
	        for(int i=1;i<cadenas.length;i++)
	             if(cadenas[i].equals(cadenas[cadenas.length - i - 1])){
	            	 hayRepetidos=true; 
	             }
	            if(hayRepetidos)
	            System.out.println("Hay cadenas de texto repetidas");
	            else
	            System.out.println("No hay cadenas de texto repetidas");
	}
}