public class Ejercicio4 {

	public static void main(String[] args) {
		
		String cadenas[] = {"Sue","CharLotte","ANNa","MiKe","William","Ed"};

		int contadorMayus = 0;
		int contadorMinus = 0;
		
		
	for(int i = 0;i<cadenas.length;i++) {
		for(int j = 0;j<cadenas[i].length();j++) {
			if(cadenas[i].charAt(j)>='A' && cadenas[i].charAt(j) <= 'Z')
				contadorMayus ++;
				
			if(cadenas[i].charAt(j)>= 'a' && cadenas[i].charAt(j) <= 'z')
				contadorMinus ++;
			
		}
		
		if(contadorMayus > contadorMinus)
			System.out.println(cadenas[i] + " Tiene más mayúsclas que minúsculas");
		if(contadorMayus < contadorMinus)
			System.out.println(cadenas[i] + " Tiene más minúsculas que mayúsculas");
		if(contadorMayus == contadorMinus)
			System.out.println(cadenas[i] + " Tiene la misma cantidad de mayúsculas y minúsculas");
		
		contadorMayus = 0;
		contadorMinus = 0;
	}
	
   }
}