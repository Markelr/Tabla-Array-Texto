public class Ejercicio11 {



	public static void main(String[] args) {

	 

		String nombres [] = {"Mike","Anna","John","Sue","Charlotte","Ed","William"};
		int cantidad [] = new int [nombres.length];

		int max = 0;

		int posmax = 0;

	
		// Guardar el array cantidad vocales en array de cada nombre 

		for (int i = 0; i<nombres.length;i++)

			for (int j = 0; j<nombres[i].length();j++)

				if (nombres [i].charAt(j)== 'a'|| nombres [i].charAt(j)== 'e'||nombres [i].charAt(j)== 'i'||nombres [i].charAt(j)== 'o'||nombres [i].charAt(j)== 'u'|| 

				    nombres [i].charAt(j)== 'A'|| nombres [i].charAt(j)== 'E'||nombres [i].charAt(j)== 'I'||nombres [i].charAt(j)== 'O'||nombres [i].charAt(j)== 'U')

					cantidad[i]++;

	
		// Mostrar en pantalla array cantidad

	
		for (int i = 0; i<nombres.length;i++)

			 System.out.println(nombres[i]+ ": "+ cantidad[i]);

	
		// Busacar max y posmax en array cantidad

	
		for (int i = 0; i<nombres.length;i++)

			if (cantidad[i]>max) {

				posmax = i;

				max = cantidad[i];

			}

		System.out.println("El nombre con más vocales es : "+ nombres[posmax] + " en la posición del array " + posmax);
	}

}