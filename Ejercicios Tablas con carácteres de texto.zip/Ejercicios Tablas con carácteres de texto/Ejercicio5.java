
public class Ejercicio5 {
    public static void main(String[] args) {

        String cadenas[]={"Sue","Charlotte","Anna","Mike","William","Ed"};

    

         for(int i=0;i<cadenas.length;i++) 

                    

        System.out.println(cadenas[i].toUpperCase());

    }

}