public class Ejercicio7 {
    public static void main(String[] args) {

    String[] cadenas = {"Suezar","Chazar","Anna","Mike","Willzariam","Ed"};

     int contador = 0;

        String subcadenaBuscada = "zar";



        // Iterar a través del array de cadenas

        for (String cadena : cadenas) {

            // Verificar si la cadena contiene la subcadena buscada

            if (cadena.contains(subcadenaBuscada)) {

                contador++;

            }

        }

        // Mostrar el resultado

        System.out.println("El número de cadenas que contiene 'zar' es: " + contador);

    }
}

