
public class Ejercicio8 {

	public static void main(String[] args) {

		String nombres [] = {"Mike","Anna","John","Sue","Charlotte","Ed","William"};

		int contador = 0;

		// Contar nombres que empiezan por P

		for (int i= 0; i<nombres.length;i++) {

			if(nombres[i].charAt(0)== 'a'|| nombres[i].charAt(0)=='A') {

				contador++;

			System.out.println(nombres[i ] + " comienza por 'a' o 'A'");}

			}

			System.out.println("Empiezan por 'a' o 'A': " + contador) ;

	}

}