public class Ejercicio2 {

	public static void main(String[] args) {

		String[] cadena ={"Sue", "Charlotte", "Anna", "Mike", "William", "Ed"};

		String primeraCadena = cadena[0];

        int posicion = 1;

        for (int i = 1; i < cadena.length; i++) {

            if (cadena[i].compareTo(primeraCadena) < 0) {

                primeraCadena = cadena[i];

                posicion = i + 1; 

                // Sumamos 1 para obtener la posición desde 1, no desde 0.

            }

        }

        System.out.println("La cadena alfabéticamente primera es: " + primeraCadena);

        System.out.println("Está en la posición: " + posicion);

	}
}